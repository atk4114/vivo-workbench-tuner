package de.robv.android.xposed.callbacks;

public abstract class XCallback implements Comparable<XCallback> {
    public int priority = 50;

    public static class Param {
        public Object[] callbacks;
    }

    @Override
    public int compareTo(XCallback other) {
        return other.priority - this.priority;
    }
}
