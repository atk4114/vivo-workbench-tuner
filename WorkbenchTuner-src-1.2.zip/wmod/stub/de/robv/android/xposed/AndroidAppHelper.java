package de.robv.android.xposed;

import android.content.Context;

public final class AndroidAppHelper {
    private AndroidAppHelper() {
    }

    public static Context currentApplication() {
        return null;
    }
}
