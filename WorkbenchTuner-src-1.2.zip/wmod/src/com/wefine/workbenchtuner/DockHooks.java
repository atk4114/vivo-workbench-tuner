package com.wefine.workbenchtuner;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;

/** Dock（任务栏）垂直偏移 + 背景圆角/透明度，作用域 com.bbk.launcher2 */
public final class DockHooks {

    private static final String TAG = "[EtaWB-Dock] ";

    private static void log(String s) {
    }

    private static int cfgY = 0;
    private static int cfgBgAlpha = 120;
    private static int cfgBgRadius = 24;
    private static volatile View dockView = null;
    private static volatile boolean polling = false;
    private static volatile int lastAppliedY = Integer.MIN_VALUE;
    private static volatile int lastTargetY = Integer.MIN_VALUE;
    private static final java.util.WeakHashMap<View, Integer> BASE_Y = new java.util.WeakHashMap<View, Integer>();

    private DockHooks() {
    }

    public static void init(ClassLoader cl) {
        try {
            Class<?> dock = XposedHelpers.findClass("com.bbk.launcher2.dock.Dock", cl);
            XposedBridge.hookAllMethods(dock, "onLayout", new LayoutHook());
            XposedBridge.hookAllConstructors(dock, new LayoutHook());
        } catch (Throwable t) {
            log(TAG + "hook Dock failed: " + t);
        }
        try {
            Class<?> wmi = XposedHelpers.findClass("android.view.WindowManagerImpl", cl);
            XposedBridge.hookAllMethods(wmi, "addView", new AddViewHook());
            XposedBridge.hookAllMethods(wmi, "updateViewLayout", new UpdateHook());
            log(TAG + "hooked WindowManagerImpl");
        } catch (Throwable t) {
            log(TAG + "hook WindowManagerImpl failed: " + t);
        }
    }

    static final class LayoutHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object self = param.thisObject;
                if (self instanceof View) {
                    dockView = (View) self;
                    readCfg();
                    startPolling();
                }
            } catch (Throwable ignored) {
            }
        }
    }

    static final class AddViewHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object view = param.args[0];
                Object lp = param.args[1];
                if (!(view instanceof View) || lp == null) {
                    return;
                }
                String cls = view.getClass().getName();
                int type = XposedHelpers.getIntField(lp, "type");
                if (type != 2038 && !cls.toLowerCase().contains("dock")) {
                    return;
                }
                dockView = (View) view;
                readCfg();
                startPolling();
                log(TAG + "dock add type=" + type + " view=" + cls);
            } catch (Throwable t) {
                log(TAG + "addView error: " + t);
            }
        }
    }

    static final class UpdateHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object v = param.args[0];
                Object lp = param.args[1];
                if (!(v instanceof View) || lp == null) {
                    return;
                }
                String cls = v.getClass().getName();
                int type = XposedHelpers.getIntField(lp, "type");
                if (type != 2038 && !cls.toLowerCase().contains("dock")) {
                    return;
                }
                readCfg();
                if (cfgY == 0) {
                    return;
                }
                View view = (View) v;
                int cur = XposedHelpers.getIntField(lp, "y");
                Integer base = BASE_Y.get(view);
                if (base == null || cur != lastTargetY) {
                    base = cur;
                    BASE_Y.put(view, base);
                }
                float d = Resources.getSystem().getDisplayMetrics().density;
                int target = base - Math.round(cfgY * d);
                lastTargetY = target;
                if (cur == target) {
                    return;
                }
                XposedHelpers.setIntField(lp, "y", target);
                WindowManager wm = (WindowManager) view.getContext().getSystemService(Context.WINDOW_SERVICE);
                wm.updateViewLayout(view, (ViewGroup.LayoutParams) lp);
                log(TAG + "dock update y=" + target + " base=" + base);
            } catch (Throwable t) {
                log(TAG + "update error: " + t);
            }
        }
    }

    private static void startPolling() {
        if (polling) {
            return;
        }
        polling = true;
        final Handler handler = new Handler(Looper.getMainLooper());
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    readCfg();
                    View view = dockView;
                    if (view != null && cfgY != lastAppliedY) {
                        ViewGroup.LayoutParams lp = view.getLayoutParams();
                        Integer base = BASE_Y.get(view);
                        if (lp instanceof WindowManager.LayoutParams && base != null) {
                            float d = Resources.getSystem().getDisplayMetrics().density;
                            int target = base - Math.round(cfgY * d);
                            XposedHelpers.setIntField(lp, "y", target);
                            WindowManager wm = (WindowManager) view.getContext()
                                    .getSystemService(Context.WINDOW_SERVICE);
                            wm.updateViewLayout(view, lp);
                            lastAppliedY = cfgY;
                            log(TAG + "live y=" + target + " cfgY=" + cfgY);
                        }
                    }
                } catch (Throwable ignored) {
                }
                handler.postDelayed(this, 400);
            }
        }, 400);
    }

    private static void applyBackground(View v) {
        try {
            clearChildBackgrounds(v);
            if (cfgBgAlpha <= 0) {
                v.setBackground(null);
            } else {
                GradientDrawable g = new GradientDrawable();
                g.setColor(Color.argb(cfgBgAlpha, 32, 32, 32));
                float d = Resources.getSystem().getDisplayMetrics().density;
                g.setCornerRadius(cfgBgRadius * d);
                v.setBackground(g);
            }
        } catch (Throwable t) {
            log(TAG + "bg error: " + t);
        }
    }

    private static void clearChildBackgrounds(View parent) {
        if (!(parent instanceof ViewGroup)) {
            return;
        }
        ViewGroup group = (ViewGroup) parent;
        for (int i = 0; i < group.getChildCount(); i++) {
            View child = group.getChildAt(i);
            try {
                child.setBackground(null);
            } catch (Throwable ignored) {
            }
            clearChildBackgrounds(child);
        }
    }

    private static void readCfg() {
        try {
            Context app = appContext();
            if (app == null) {
                return;
            }
            String v = Settings.Global.getString(app.getContentResolver(), "eta_dock_y");
            cfgY = v == null ? 0 : Integer.parseInt(v);
            String a = Settings.Global.getString(app.getContentResolver(), "eta_dock_bg_alpha");
            cfgBgAlpha = a == null ? 120 : Integer.parseInt(a);
            String r = Settings.Global.getString(app.getContentResolver(), "eta_dock_bg_radius");
            cfgBgRadius = r == null ? 24 : Integer.parseInt(r);
        } catch (Throwable ignored) {
        }
    }

    private static Context appContext() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) {
                return (Context) app;
            }
        } catch (Throwable ignored) {
        }
        return null;
    }
}

