package com.wefine.workbenchtuner;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.IdentityHashMap;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * v2.7：动画路径(PointInfo) + 静止路径(dispatchDraw) 同时应用，避免双重缩放；图标跟随。
 */
public class HookEntry implements IXposedHookLoadPackage {

    public static final String TAG = "[EtaWB] ";

    private static void log(String s) {
    }
    private static final String LM = "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskLocationManager";
    private static final String PERSPECTIVE =
            "com.android.wm.shell.vivomultitask.vivomultitaskui.leftrightui.VivoMultiTaskPerspectiveLayout";
    private static final String ADAPTER =
            "com.android.wm.shell.vivomultitask.vivomultitaskui.leftrightui.VivoMultiTaskLeftRightAdapter";
    private static final String HOLDER =
            "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskItemHolder";
    private static final String STATE = "com.android.wm.shell.vivomultitask.VivoMultiTaskState";
    private static final String PROVIDER = "content://com.wefine.workbenchtuner.config/config";

    private static float cfgScale = 1.0f;
    private static float cfgDx = 0.0f;
    private static float cfgDy = 0.0f;
    private static float cfgSide = 1.0f;
    private static float cfgSideDx = 0.0f;
    private static float cfgPersp = 0.0f;
    private static boolean cfgSideRight = false;
    private static float cfgIconDx = 0.0f;
    private static long lastRead = 0L;
    private static boolean providerBroken = false;
    private static float cfgCastScale = 1.0f;
    private static final java.util.WeakHashMap<android.view.View, int[]> CAST_BASE =
            new java.util.WeakHashMap<android.view.View, int[]>();
    private static Context sCtx = null;

    private static void setCtx(Context c) {
        if (c != null) {
            sCtx = c;
        }
    }

    private static Context ctx() {
        return sCtx != null ? sCtx : appContext();
    }
    private static int logCount = 0;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if ("com.bbk.launcher2".equals(lpparam.packageName)) {
            log(TAG + "dock module loading in launcher");
            DockHooks.init(lpparam.classLoader);
            return;
        }
        if (!"com.android.systemui".equals(lpparam.packageName)) {
            return;
        }
        log(TAG + "v3.1 loaded process=" + lpparam.processName);

        ClassLoader cl = lpparam.classLoader;
        try {
            Class<?> stateClass = XposedHelpers.findClass(STATE, cl);
            hookMainPoint(cl, stateClass, "getMainTaskPointInfoLeftRight");
            hookMainPoint(cl, stateClass, "getMainTaskPointInfoLeftRight_v2");
        } catch (Throwable t) {
            log(TAG + "main setup failed: " + t);
        }
        hookSideList(cl);
        hookPerspective(cl);
        hookSwipe(cl);
        hookAdapterDebug(cl);
        hookAdapterIcon(cl);
        probeReplace(cl);
        hookExit(cl);

        readConfig(true);
        log(TAG + "initial config main=" + cfgScale + " side=" + cfgSide
                + " sideDx=" + cfgSideDx);
    }

    private void hookMainPoint(ClassLoader cl, Class<?> stateClass, String name) {
        try {
            XposedHelpers.findAndHookMethod(LM, cl, name, stateClass, boolean.class, new MainPointHook(name));
            log(TAG + "hooked " + name);
        } catch (Throwable t) {
            log(TAG + "hook " + name + " skipped: " + t);
        }
    }

    private void hookSideList(ClassLoader cl) {
        try {
            XposedHelpers.findAndHookMethod(LM, cl, "calculatePointInfoLeftRight",
                    int.class, int.class, int.class, int.class, float.class, int.class, boolean.class,
                    new SideListHook());
            log(TAG + "hooked calculatePointInfoLeftRight");
        } catch (Throwable t) {
            log(TAG + "hook calculatePointInfoLeftRight skipped: " + t);
        }
    }

    private void hookPerspective(ClassLoader cl) {
        try {
            Class<?> cls = XposedHelpers.findClass(PERSPECTIVE, cl);
            java.util.Set<XC_MethodHook.Unhook> set =
                    XposedBridge.hookAllMethods(cls, "dispatchDraw", new DispatchHook());
            log(TAG + "hooked PerspectiveLayout.dispatchDraw x"
                    + (set == null ? -1 : set.size()));
        } catch (Throwable t) {
            log(TAG + "hook PerspectiveLayout skipped: " + t);
        }
    }

    private void hookAdapterIcon(ClassLoader cl) {
        try {
            Class<?> holder = XposedHelpers.findClass(HOLDER, cl);
            Class<?> state = XposedHelpers.findClass(STATE, cl);
            Class<?> adapter = XposedHelpers.findClass(ADAPTER, cl);
            XposedHelpers.findAndHookMethod(adapter, "onBuildMultiTaskHolder",
                    holder, int.class, state, new IconHook());
            log(TAG + "hooked onBuildMultiTaskHolder");
        } catch (Throwable t) {
            log(TAG + "hook onBuildMultiTaskHolder skipped: " + t);
        }
    }

    private void probeReplace(ClassLoader cl) {
        try {
            Class<?> ui = XposedHelpers.findClass(
                    "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskUiModel", cl);
            for (java.lang.reflect.Method m : ui.getDeclaredMethods()) {
                XposedBridge.hookMethod(m, new ProbeHook());
            }
            try {
                Class<?> coord = XposedHelpers.findClass(
                        "com.android.wm.shell.vivomultitask.VivoMultiTaskCoordinator", cl);
                for (java.lang.reflect.Method m : coord.getDeclaredMethods()) {
                    String n = m.getName().toLowerCase();
                    if (n.contains("replace") || n.contains("switch") || n.contains("change")) {
                        XposedBridge.hookMethod(m, new ProbeHook());
                    }
                }
            } catch (Throwable ignored) {
            }
            log("probed replace methods");
        } catch (Throwable t) {
            log("probe replace failed: " + t);
        }
    }

    private void hookExit(ClassLoader cl) {
        try {
            Class<?> ui = XposedHelpers.findClass(
                    "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskUiModel", cl);
            XposedBridge.hookAllMethods(ui, "exitVivoMultiTaskByButton", new ExitHook());
            for (java.lang.reflect.Method m : ui.getDeclaredMethods()) {
                String n = m.getName().toLowerCase();
                if (n.startsWith("exit") || n.contains("exittask") || n.contains("onexit")) {
                    XposedBridge.hookMethod(m, new ExitHook());
                }
            }
            try {
                Class<?> coord = XposedHelpers.findClass(
                        "com.android.wm.shell.vivomultitask.VivoMultiTaskCoordinator", cl);
                for (java.lang.reflect.Method m : coord.getDeclaredMethods()) {
                    String n = m.getName().toLowerCase();
                    if (n.startsWith("exit") || n.contains("onexit")) {
                        XposedBridge.hookMethod(m, new ExitHook());
                    }
                }
            } catch (Throwable ignored) {
            }
            try {
                Class<?> coord = XposedHelpers.findClass(
                        "com.android.wm.shell.vivomultitask.VivoMultiTaskCoordinator", cl);
                probeCloseMethods(coord);
            } catch (Throwable ignored) {
            }
            log("hooked exit");
        } catch (Throwable t) {
            log("hook exit failed: " + t);
        }
    }

    static final class ExitHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            removeMainDeleteButton();
        }
    }

    private static void probeAtmProxy(ClassLoader cl) {
        String[] names = {
                "com.android.server.wm.IActivityTaskManager$Stub$Proxy",
                "android.app.IActivityTaskManager$Stub$Proxy"
        };
        for (String n : names) {
            try {
                Class<?> proxy = XposedHelpers.findClass(n, cl);
                for (java.lang.reflect.Method m : proxy.getDeclaredMethods()) {
                    if (m.getName().equals("removeTask")) {
                        XposedBridge.hookMethod(m, new ProbeHook());
                        log("hooked ATM proxy removeTask: " + m);
                    }
                }
            } catch (Throwable t) {
                log("probe ATM fail " + n + ": " + t);
            }
        }
    }

    private static void probeCloseMethods(Class<?> cls) {
        try {
            for (java.lang.reflect.Method m : cls.getDeclaredMethods()) {
                String n = m.getName().toLowerCase();
                if (n.contains("close") || n.contains("remove") || n.contains("exit") || n.contains("del")) {
                    XposedBridge.hookMethod(m, new ProbeHook());
                }
            }
            log("probed " + cls.getSimpleName());
        } catch (Throwable t) {
            log("probe failed: " + t);
        }
    }

    static final class ProbeHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            String n = param.method.getName();
            if ("removeTaskFromVivoMultiTask".equals(n)) {
                sMmMethod = (java.lang.reflect.Method) param.method;
                sMmTarget = param.thisObject;
                StringBuilder sb = new StringBuilder();
                for (Object a : param.args) {
                    sb.append(a == null ? "null" : a.getClass().getSimpleName()).append(",");
                }
                log("captured removeTaskFromVivoMultiTask on "
                        + param.method.getDeclaringClass().getSimpleName() + " types=" + sb);
            }
            if ("removeTaskIfNeed".equals(n)) {
                sRemoveMethod = (java.lang.reflect.Method) param.method;
                sRemoveTarget = param.thisObject;
                String extra = "";
                try {
                    Object a0 = param.args.length > 0 ? param.args[0] : null;
                    if (a0 instanceof java.util.List) {
                        extra = " listSize=" + ((java.util.List) a0).size();
                    } else if (a0 != null) {
                        extra = " arg0=" + a0.getClass().getSimpleName();
                    }
                } catch (Throwable ignored) {
                }
                log("captured removeTaskIfNeed on "
                        + param.method.getDeclaringClass().getSimpleName() + extra);
            }
            log("called " + n + " args=" + param.args.length);
        }
    }

    private static void removeMainDeleteButton() {
        try {
            if (sMainDelBtn != null) {
                android.content.Context ctx = appContext();
                if (ctx != null) {
                    android.view.WindowManager wm = (android.view.WindowManager)
                            ctx.getSystemService(android.content.Context.WINDOW_SERVICE);
                    wm.removeView(sMainDelBtn);
                    if (sReplaceBtn != null) {
                        try {
                            wm.removeView(sReplaceBtn);
                        } catch (Throwable ignored) {
                        }
                        sReplaceBtn = null;
                    }
                }
                sMainDelBtn = null;
                log("main delete button removed");
            }
        } catch (Throwable t) {
            log("remove del btn failed: " + t);
        }
    }

    private void hookSwipeConfirm(ClassLoader cl) {
        try {
            Class<?> ui = XposedHelpers.findClass(
                    "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskUiModel", cl);
            XposedBridge.hookAllMethods(ui, "onSwipeUpOrCancel", new SwipeConfirmHook());
            log("hooked onSwipeUpOrCancel");
        } catch (Throwable t) {
            log("hook swipe confirm failed: " + t);
        }
    }

    static final class SwipeConfirmHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                Object ui = param.thisObject;
                Object state = param.args.length > 0 ? param.args[0] : null;
                log(TAG + "swipeUpOrCancel args=" + param.args.length);
                XposedHelpers.callMethod(ui, "exitVivoMultiTaskByButton");
                log("swipe confirm exit called");
            } catch (Throwable t) {
                log("swipe confirm fail: " + t);
            }
        }
    }

    private void hookSwipe(ClassLoader cl) {
        hookSwipeMethod(cl, "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskSlideHelper", "onTouchEvent");
        hookSwipeMethod(cl, "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskSlideHelper", "onInterceptTouchEvent");
        hookSwipeMethod(cl, "com.android.wm.shell.vivomultitask.vivomultitaskui.leftrightui.VivoMultiTaskLeftRightAdapter", "onSwipeMove");
        hookSwipeMethod(cl, "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskUiModel", "onSwipeMove");
        hookSwipeMethod(cl, "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskUiModel", "onSwipeUpOrCancel");
    }

    private void hookSwipeMethod(ClassLoader cl, String className, String method) {
        try {
            Class<?> cls = XposedHelpers.findClass(className, cl);
            boolean touch = method.startsWith("onTouch") || method.startsWith("onIntercept");
            int n = XposedBridge.hookAllMethods(cls, method,
                    touch ? new SlideTouchHook() : new SwipeHook()).size();
            log(TAG + "hooked " + cls.getSimpleName() + "#" + method + " x" + n);
        } catch (Throwable t) {
            log(TAG + "hook " + method + " failed: " + t);
        }
    }

    static final class SlideTouchHook extends XC_MethodHook {
        private float downX = -1f;

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                Object ev0 = param.args.length > 0 ? param.args[0] : null;
                if (!(ev0 instanceof android.view.MotionEvent)) {
                    return;
                }
                android.view.MotionEvent ev = (android.view.MotionEvent) ev0;
                int action = ev.getActionMasked();
                if (action == android.view.MotionEvent.ACTION_DOWN) {
                    downX = ev.getX();
                    return;
                }
                if (action != android.view.MotionEvent.ACTION_MOVE || downX < 0) {
                    return;
                }
                if (ev.getX() <= downX) {
                    return;
                }
                android.view.View child = null;
                try {
                    child = (android.view.View) XposedHelpers.getObjectField(param.thisObject, "mChildView");
                } catch (Throwable ignored) {
                }
                if (child == null || child.getWidth() <= 0) {
                    return;
                }
                int w = child.getWidth();
                ev.setLocation(w - ev.getX(), ev.getY());
                log(TAG + "right swipe mirrored");
            } catch (Throwable ignored) {
            }
        }
    }

    static final class SwipeHook extends XC_MethodHook {
        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                String name = param.method.getName();
                if (!"onSwipeMove".equals(name) || param.args.length < 1) {
                    return;
                }
                Object a0 = param.args[0];
                if (a0 instanceof Integer) {
                    int dir = (Integer) a0;
                    int out = dir;
                    if (dir > 0) {
                        out = -dir;          // 右划伪装成左划
                    }
                    out = out * 2;           // 位移放大，删除距离减半
                    param.args[0] = out;
                    log(TAG + "swipe dir " + dir + " -> " + out);
                }
            } catch (Throwable ignored) {}
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                if (!"onSwipeMove".equals(param.method.getName())) {
                    return;
                }
                Object a0 = param.args[0];
                log(TAG + "swipe onSwipeMove dir=" + a0);
            } catch (Throwable ignored) {}
        }
    }

    private void hookCast(ClassLoader cl) {
        try {
            Class<?> wmi = XposedHelpers.findClass("android.view.WindowManagerImpl", cl);
            XposedBridge.hookAllMethods(wmi, "addView", new CastWindowHook());
            XposedBridge.hookAllMethods(wmi, "updateViewLayout", new CastWindowHook());
            log(TAG + "hooked cast windows");
        } catch (Throwable t) {
            log(TAG + "hook cast failed: " + t);
        }
    }

    static final class CastWindowHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object v = param.args[0];
                Object lp = param.args[1];
                if (!(v instanceof android.view.View) || lp == null) {
                    return;
                }
                int type = XposedHelpers.getIntField(lp, "type");
                if (type != 2038) {
                    return;
                }
                String cls = v.getClass().getName().toLowerCase();
                if (!cls.contains("cast") && !cls.contains("upnp") && !cls.contains("mirror")) {
                    return;
                }
                android.view.View view = (android.view.View) v;
                float scale = readCastScale(view.getContext());
                if (scale == 1.0f) {
                    return;
                }
                int w = XposedHelpers.getIntField(lp, "width");
                int h = XposedHelpers.getIntField(lp, "height");
                if (w <= 0 || h <= 0) {
                    return;
                }
                int[] base = CAST_BASE.get(view);
                if (base == null) {
                    base = new int[]{w, h};
                    CAST_BASE.put(view, base);
                }
                int targetW = Math.round(base[0] * scale);
                int targetH = Math.round(base[1] * scale);
                if (w == targetW && h == targetH) {
                    return;
                }
                XposedHelpers.setIntField(lp, "width", targetW);
                XposedHelpers.setIntField(lp, "height", targetH);
                android.view.WindowManager wm = (android.view.WindowManager)
                        view.getContext().getSystemService(android.content.Context.WINDOW_SERVICE);
                wm.updateViewLayout(view, (android.view.ViewGroup.LayoutParams) lp);
                log(TAG + "cast resize " + base[0] + "x" + base[1]
                        + " -> " + targetW + "x" + targetH);
            } catch (Throwable t) {
                log(TAG + "cast error: " + t);
            }
        }
    }

    private static float readCastScale(android.content.Context c) {
        try {
            String v = android.provider.Settings.Global.getString(c.getContentResolver(), "eta_cast_scale");
            if (v != null) {
                return Float.parseFloat(v);
            }
        } catch (Throwable ignored) {
        }
        return 1.0f;
    }

    private void hookAdapterDebug(ClassLoader cl) {
        try {
            Class<?> adapter = XposedHelpers.findClass(
                    "com.android.wm.shell.vivomultitask.vivomultitaskui.leftrightui.VivoMultiTaskLeftRightAdapter", cl);
            XposedBridge.hookAllMethods(adapter, "getItemCount", new CountHook());
            try {
                Class<?> base = XposedHelpers.findClass(
                        "com.android.wm.shell.vivomultitask.vivomultitaskui.VivoMultiTaskBaseAdapter", cl);
                XposedBridge.hookAllMethods(base, "getItemCount", new CountHook());
                sAdapterClass = base;
                log(TAG + "hooked base adapter");
            } catch (Throwable ignored) {
            }
            XposedBridge.hookAllMethods(adapter, "getItemViewType", new TypeHook());
            log(TAG + "hooked adapter debug");
        } catch (Throwable t) {
            log(TAG + "hook adapter debug failed: " + t);
        }
    }

    static Class<?> sAdapterClass = null;

    static final class CountHook extends XC_MethodHook {
        private int last = -1;
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                int c = (Integer) param.getResult();
                if (c > 0 && c < 8) {
                    param.setResult(c + 1);
                    if (c != last) {
                        last = c;
                        log(TAG + "getItemCount=" + c + " -> " + (c + 1));
                    }
                }
            } catch (Throwable ignored) {}
        }
    }

    static final class TypeHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                int pos = (Integer) param.args[0];
                int type = (Integer) param.getResult();
                if (pos >= 4 && sAdapterClass != null) {
                    int addType = XposedHelpers.getStaticIntField(sAdapterClass, "TYPE_ADD_TASK_VIEW");
                    param.setResult(addType);
                    log(TAG + "type pos=" + pos + " -> add(" + addType + ")");
                }
            } catch (Throwable ignored) {}
        }
    }

    static final class MainPointHook extends XC_MethodHook {

        private final String name;

        MainPointHook(String n) {
            name = n;
        }

        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object info = param.getResult();
                if (info == null) {
                    return;
                }
                readConfig(false);
                if (cfgScale == 1.0f && cfgDx == 0.0f && cfgDy == 0.0f) {
                    return;
                }
                Point lt = (Point) XposedHelpers.getObjectField(info, "mPointLT");
                Point rt = (Point) XposedHelpers.getObjectField(info, "mPointRT");
                Point lb = (Point) XposedHelpers.getObjectField(info, "mPointLB");
                Point rb = (Point) XposedHelpers.getObjectField(info, "mPointRB");
                if (lt == null || rt == null || lb == null || rb == null) {
                    return;
                }
                float cx = (lt.x + rb.x) / 2.0f;
                float cy = (lt.y + rb.y) / 2.0f;
                float d = Resources.getSystem().getDisplayMetrics().density;
                float dx = cfgDx * d;
                float dy = cfgDy * d;
                scalePoint(lt, cx, cy, cfgScale, dx, dy);
                scalePoint(rt, cx, cy, cfgScale, dx, dy);
                scalePoint(lb, cx, cy, cfgScale, dx, dy);
                scalePoint(rb, cx, cy, cfgScale, dx, dy);
                try {
                    sMainState = param.args[0];
                    sMainTaskId = resolveTaskId(param.args[0]);
                } catch (Throwable ignored) {
                }
                showMainDeleteButton(rt.x, lt.y);
                startWatcher();
            } catch (Throwable t) {
                if (logCount < 8) {
                    logCount++;
                    log(TAG + name + " apply error: " + t);
                }
            }
        }
    }

    /** 动画路径：缩放 + 偏移 */
    static final class SideListHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                Object info = param.getResult();
                if (info == null) {
                    return;
                }
                readConfig(false);
                if (cfgSide == 1.0f && cfgSideDx == 0.0f) {
                    return;
                }
                Point lt = (Point) XposedHelpers.getObjectField(info, "mPointLT");
                Point rt = (Point) XposedHelpers.getObjectField(info, "mPointRT");
                Point lb = (Point) XposedHelpers.getObjectField(info, "mPointLB");
                Point rb = (Point) XposedHelpers.getObjectField(info, "mPointRB");
                if (lt == null || rt == null || lb == null || rb == null) {
                    return;
                }
                float cx = (lt.x + rb.x) / 2.0f;
                float cy = (lt.y + rb.y) / 2.0f;
                float d = Resources.getSystem().getDisplayMetrics().density;
                float dx = cfgSideDx * d;
                scalePoint(lt, cx, cy, cfgSide, dx, 0f);
                scalePoint(rt, cx, cy, cfgSide, dx, 0f);
                scalePoint(lb, cx, cy, cfgSide, dx, 0f);
                scalePoint(rb, cx, cy, cfgSide, dx, 0f);
                if (cfgSideRight) {
                    int w = Resources.getSystem().getDisplayMetrics().widthPixels;
                    int ltx = lt.x, lty = lt.y, rtx = rt.x, rty = rt.y;
                    lt.x = w - rtx;
                    lt.y = rty;
                    rt.x = w - ltx;
                    rt.y = lty;
                    int lbx = lb.x, lby = lb.y, rbx = rb.x, rby = rb.y;
                    lb.x = w - rbx;
                    lb.y = rby;
                    rb.x = w - lbx;
                    rb.y = lby;
                }
                float cx2 = (lt.x + rb.x) / 2.0f;
                float cy2 = (lt.y + rb.y) / 2.0f;
                float halfW = Math.max(1f, (rt.x - lt.x) / 2.0f);
                float k = 0f;
                applyPersp(lt, cx2, cy2, halfW, k);
                applyPersp(rt, cx2, cy2, halfW, k);
                applyPersp(lb, cx2, cy2, halfW, k);
                applyPersp(rb, cx2, cy2, halfW, k);
            } catch (Throwable t) {
                if (logCount < 8) {
                    logCount++;
                    log(TAG + "sideList error: " + t);
                }
            }
        }
    }

    /** 静止路径：检测是否已缩放，避免双重 */
    static final class DispatchHook extends XC_MethodHook {

        private final IdentityHashMap<Object, int[]> origin = new IdentityHashMap<Object, int[]>();

        @Override
        protected void beforeHookedMethod(MethodHookParam param) {
            try {
                readConfig(false);
                if (cfgSide == 1.0f && cfgSideDx == 0.0f) {
                    return;
                }
                Object layout = param.thisObject;
                if (layout instanceof android.view.View) {
                    android.content.Context vc = ((android.view.View) layout).getContext();
                    setCtx(vc);
                    long now = System.currentTimeMillis();
                    if (now - lastRead > 2000) {
                        lastRead = now;
                        try {
                            android.content.ContentResolver cr = vc.getContentResolver();
                            String s = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_SCALE);
                            String sd = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_SCALE);
                            String sx = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_OFFSET_X);
                            String x = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_OFFSET_X);
                            String p = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_PERSPECTIVE);
                            log(TAG + "viewctx main=" + s + " side=" + sd + " sideDx=" + sx);
                            cfgScale = parse(s, 1.0f);
                            cfgSide = parse(sd, 1.0f);
                            cfgSideDx = parse(sx, 0.0f);
                            cfgDx = parse(x, 0.0f);
                            cfgPersp = parse(p, 0.0f);
                        } catch (Throwable t) {
                            log(TAG + "viewctx error: " + t);
                        }
                    }
                }
                Object arr = XposedHelpers.getObjectField(layout, "mDstLocation");
                if (!(arr instanceof Point[])) {
                    return;
                }
                Point[] pts = (Point[]) arr;
                if (pts.length == 0) {
                    return;
                }
                int[] orig = origin.get(layout);
                if (orig == null || orig.length != pts.length * 2) {
                    orig = new int[pts.length * 2];
                    for (int i = 0; i < pts.length; i++) {
                        orig[i * 2] = pts[i].x;
                        orig[i * 2 + 1] = pts[i].y;
                    }
                    origin.put(layout, orig);
                }
                int minX = Integer.MAX_VALUE;
                int maxX = Integer.MIN_VALUE;
                int curMinX = Integer.MAX_VALUE;
                int curMaxX = Integer.MIN_VALUE;
                for (int i = 0; i < pts.length; i++) {
                    minX = Math.min(minX, orig[i * 2]);
                    maxX = Math.max(maxX, orig[i * 2]);
                    curMinX = Math.min(curMinX, pts[i].x);
                    curMaxX = Math.max(curMaxX, pts[i].x);
                }
                int w0 = maxX - minX;
                int wCur = curMaxX - curMinX;
                // 统一口径：静止态每帧都按默认值重新应用一次，动画与静止保持一致
                boolean alreadyScaled = false;

                float cx = 0f;
                float cy = 0f;
                for (int i = 0; i < pts.length; i++) {
                    cx += orig[i * 2];
                    cy += orig[i * 2 + 1];
                }
                cx /= pts.length;
                cy /= pts.length;
                float d = Resources.getSystem().getDisplayMetrics().density;
                float dx = cfgSideDx * d;
                float scale = alreadyScaled ? 1.0f : cfgSide;
                float k = 0f;
                float halfW = Math.max(1f, (maxX - minX) / 2.0f);
                for (int i = 0; i < pts.length; i++) {
                    float nx = cx + (orig[i * 2] - cx) * scale;
                    if (cfgSideRight) {
                        int vw = 0;
                        Object lay = param.thisObject;
                        if (lay instanceof android.view.View) {
                            vw = ((android.view.View) lay).getWidth();
                            int screenW = Resources.getSystem().getDisplayMetrics().widthPixels;
                            ((android.view.View) lay).setTranslationX(screenW - ((android.view.View) lay).getRight());
                        }
                        nx = (vw > 0 ? vw : Resources.getSystem().getDisplayMetrics().widthPixels) - nx;
                    }
                    nx += dx;
                    float ny = cy + (orig[i * 2 + 1] - cy) * scale;
                    float f = 1.0f + k * ((nx - cx) / halfW);
                    pts[i].x = Math.round(nx);
                    pts[i].y = Math.round(cy + (ny - cy) * f);
                }
            } catch (Throwable t) {
                if (logCount < 8) {
                    logCount++;
                    log(TAG + "perspective error: " + t);
                }
            }
        }
    }

    static final class IconHook extends XC_MethodHook {
        @Override
        protected void afterHookedMethod(MethodHookParam param) {
            try {
                readConfig(false);
                if (cfgIconDx == 0.0f) {
                    return;
                }
                Object holder = param.args[0];
                try {
                    sUiModel = XposedHelpers.getObjectField(param.thisObject, "mVivoMultiTaskUiModel");
                } catch (Throwable ignored) {
                }
                Object layout = null;
                try {
                    layout = XposedHelpers.getObjectField(holder, "itemView");
                } catch (Throwable ignored) {
                }
                if (!(layout instanceof ViewGroup)) {
                    layout = XposedHelpers.callMethod(holder, "getTaskItemLayout");
                }
                if (!(layout instanceof ViewGroup)) {
                    return;
                }
                float d = Resources.getSystem().getDisplayMetrics().density;
                int dx = Math.round(cfgIconDx * d);
                int moved = moveIcons((ViewGroup) layout, dx);
                if (logCount < 12) {
                    logCount++;
                    log(TAG + "icon shift dx=" + cfgIconDx + "dp moved=" + moved);
                }
            } catch (Throwable t) {
                if (logCount < 8) {
                    logCount++;
                    log(TAG + "icon error: " + t);
                }
            }
        }
    }

    private static View sMainDelBtn = null;
    private static View sReplaceBtn = null;
    private static volatile Object sUiModel = null;
    private static volatile Object sMainState = null;
    private static volatile int sMainTaskId = -1;
    private static volatile android.view.View sTaskView = null;
    private static volatile boolean sWatchStarted = false;
    private static volatile java.lang.reflect.Method sRemoveMethod = null;
    private static volatile Object sRemoveTarget = null;
    private static volatile java.lang.reflect.Method sMmMethod = null;
    private static volatile Object sMmTarget = null;

    private static void showMainDeleteButton(int x, int y) {
        try {
            android.view.View tv = sTaskView;
            if (tv != null && (!tv.isShown()
                    || tv.getWindowVisibility() != android.view.View.VISIBLE)) {
                return;
            }
            final android.content.Context ctx = appContext();
            if (ctx == null) {
                log("no ctx for del btn");
                return;
            }
            final android.view.WindowManager wm = (android.view.WindowManager)
                    ctx.getSystemService(android.content.Context.WINDOW_SERVICE);
            if (sMainDelBtn == null) {
                android.widget.TextView btn = new android.widget.TextView(ctx);
                btn.setText("×");
                btn.setTextColor(0xFF000000);
                btn.setTextSize(22);
                btn.setGravity(17);
                btn.setBackground(null);
                btn.setOnClickListener(new MainDeleteClick());
                android.view.WindowManager.LayoutParams lp = new android.view.WindowManager.LayoutParams(
                        64, 64,
                        android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                                | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        android.graphics.PixelFormat.TRANSLUCENT);
                lp.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                lp.x = x - 64;
                lp.y = y - 96;
                wm.addView(btn, lp);
                sMainDelBtn = btn;
                android.widget.TextView rb = new android.widget.TextView(ctx);
                rb.setText("◇");
                rb.setTextColor(0xFF000000);
                rb.setTextSize(18);
                rb.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                rb.setScaleX(0.7f);
                rb.setScaleY(0.7f);
                rb.setGravity(17);
                rb.setBackground(null);
                rb.setOnClickListener(new ReplaceClick());
                android.view.WindowManager.LayoutParams rlp = new android.view.WindowManager.LayoutParams(
                        64, 64,
                        android.view.WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                        android.view.WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                | android.view.WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                                | android.view.WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                        android.graphics.PixelFormat.TRANSLUCENT);
                rlp.gravity = android.view.Gravity.TOP | android.view.Gravity.LEFT;
                rlp.x = lp.x - 64;
                rlp.y = lp.y + 7;
                wm.addView(rb, rlp);
                sReplaceBtn = rb;
                log("main delete button added at " + lp.x + "," + lp.y);
            } else {
                android.view.WindowManager.LayoutParams lp =
                        (android.view.WindowManager.LayoutParams) sMainDelBtn.getLayoutParams();
                lp.x = x - 64;
                lp.y = y - 96;
                wm.updateViewLayout(sMainDelBtn, lp);
            }
        } catch (Throwable t) {
            log("main del btn failed: " + t);
        }
    }

    static final class ReplaceClick implements android.view.View.OnClickListener {
        @Override
        public void onClick(android.view.View v) {
            try {
                Object state = sMainState;
                Object ui = sUiModel;
                if (state == null || ui == null) {
                    log("replace: no state/ui");
                    return;
                }
                Object coord = null;
                try {
                    coord = XposedHelpers.callMethod(ui, "getVivoMultiTaskCoordinator");
                } catch (Throwable ignored) {
                }
                if (coord == null) {
                    log("replace: no coordinator");
                    return;
                }
                Object ti = null;
                String[] tf = {"mTaskInfo", "taskInfo", "mTaskinfo"};
                for (String f : tf) {
                    try {
                        ti = XposedHelpers.getObjectField(state, f);
                        if (ti != null) {
                            break;
                        }
                    } catch (Throwable ignored) {
                    }
                }
                java.lang.reflect.Method m = null;
                for (java.lang.reflect.Method mm : coord.getClass().getDeclaredMethods()) {
                    if ("startLauncherSubWindow".equals(mm.getName())) {
                        m = mm;
                        break;
                    }
                }
                if (m == null) {
                    log("replace: method missing");
                    return;
                }
                m.setAccessible(true);
                Class<?>[] pt = m.getParameterTypes();
                Object[] av = new Object[pt.length];
                for (int i = 0; i < pt.length; i++) {
                    String tn = pt[i].getName();
                    if (pt[i] == boolean.class) {
                        av[i] = Boolean.FALSE;
                    } else if (pt[i] == int.class) {
                        av[i] = sMainTaskId;
                    } else if (tn.contains("RunningTaskInfo")) {
                        av[i] = ti;
                    } else {
                        av[i] = state;
                    }
                }
                m.invoke(coord, av);
                log("replace invoked");
            } catch (java.lang.reflect.InvocationTargetException ite) {
                log("replace cause: " + ite.getCause());
            } catch (Throwable t) {
                log("replace fail: " + t);
            }
        }
    }

    static final class MainDeleteClick implements android.view.View.OnClickListener {
        @Override
        public void onClick(android.view.View v) {
            try {
                Object state = sMainState;
                Object ui = sUiModel;
                if (state == null || ui == null) {
                    log("delete: missing state/ui");
                    return;
                }
                Object coord;
                try {
                    coord = XposedHelpers.callMethod(ui, "getVivoMultiTaskCoordinator");
                } catch (Throwable t) {
                    coord = null;
                }
                if (coord == null) {
                    log("delete: no coordinator");
                    return;
                }
                Object ti = null;
                String[] tf = {"mTaskInfo", "taskInfo", "mTaskinfo"};
                for (String f : tf) {
                    try {
                        ti = XposedHelpers.getObjectField(state, f);
                        if (ti != null) {
                            break;
                        }
                    } catch (Throwable ignored) {
                    }
                }
                java.lang.reflect.Method m = null;
                for (java.lang.reflect.Method mm : coord.getClass().getDeclaredMethods()) {
                    if ("removeTaskFromVivoMultiTask".equals(mm.getName())) {
                        m = mm;
                        break;
                    }
                }
                if (m == null || ti == null) {
                    log("delete: method/taskInfo missing");
                    return;
                }
                m.setAccessible(true);
                Class<?>[] pt = m.getParameterTypes();
                Object[] av = new Object[pt.length];
                for (int i = 0; i < pt.length; i++) {
                    String tn = pt[i].getName();
                    if (pt[i] == int.class) {
                        av[i] = sMainTaskId;
                    } else if (pt[i] == boolean.class) {
                        av[i] = Boolean.FALSE;
                    } else if (tn.contains("RunningTaskInfo")) {
                        av[i] = ti;
                    } else if (tn.contains("WindowContainerTransaction")) {
                        Class<?> wctCls = XposedHelpers.findClass(
                                "android.window.WindowContainerTransaction", null);
                        av[i] = wctCls.getConstructor().newInstance();
                    } else {
                        av[i] = state;
                    }
                }
                m.invoke(coord, av);
                log("delete ok");
            } catch (java.lang.reflect.InvocationTargetException ite) {
                log("delete cause: " + ite.getCause());
            } catch (Throwable t) {
                log("delete fail: " + t);
            }
        }
    }

    private static int resolveTaskId(Object state) {
        int tid = -1;
        String[] fields = {"mTaskId", "taskId", "mTaskID"};
        for (String f : fields) {
            try {
                tid = XposedHelpers.getIntField(state, f);
                if (tid > 0) {
                    return tid;
                }
            } catch (Throwable ignored) {
            }
        }
        try {
            Object r = XposedHelpers.callMethod(state, "getTaskId");
            if (r instanceof Integer) {
                return (Integer) r;
            }
        } catch (Throwable ignored) {
        }
        try {
            String str = state.toString();
            int idx = str.indexOf("taskId-");
            if (idx >= 0) {
                int end = idx + 7;
                while (end < str.length() && Character.isDigit(str.charAt(end))) {
                    end++;
                }
                return Integer.parseInt(str.substring(idx + 7, end));
            }
        } catch (Throwable ignored) {
        }
        return tid;
    }

    private static void startWatcher() {
        if (sWatchStarted) {
            return;
        }
        sWatchStarted = true;
        final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        h.postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    try {
                        android.content.Context c = appContext();
                        if (c != null) {
                            android.app.ActivityManager am = (android.app.ActivityManager)
                                    c.getSystemService(android.content.Context.ACTIVITY_SERVICE);
                            java.util.List<android.app.ActivityManager.RunningTaskInfo> ts =
                                    am.getRunningTasks(1);
                            if (ts != null && !ts.isEmpty() && ts.get(0).topActivity != null) {
                                String pkg = ts.get(0).topActivity.getPackageName();
                                log("top pkg=" + pkg);
                                if ("com.bbk.launcher2".equals(pkg)
                                        || "com.vivo.hiboard".equals(pkg)
                                        || "com.vivo.recents".equals(pkg)
                                        || "com.android.launcher3".equals(pkg)) {
                                    removeMainDeleteButton();
                                }
                            }
                        }
                    } catch (Throwable t) {
                        log("top pkg err: " + t);
                    }
                    android.view.View tv = sTaskView;
                    if (sMainDelBtn != null && tv != null) {
                        android.graphics.Rect r = new android.graphics.Rect();
                        boolean visible = tv.isShown()
                                && tv.getGlobalVisibleRect(r) && r.width() > 50 && r.height() > 50;
                        if (visible) {
                            try {
                                android.view.View rootV = tv.getRootView();
                                if (rootV != null) {
                                    Object vri = XposedHelpers.callMethod(rootV, "getViewRootImpl");
                                    Object ai = XposedHelpers.getObjectField(vri, "mAttachInfo");
                                    int vis = XposedHelpers.getIntField(ai, "mWindowVisibility");
                                    if (vis != 0) {
                                        visible = false;
                                    }
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                        if (visible) {
                            try {
                                android.content.Context c0 = appContext();
                                if (c0 != null) {
                                    android.app.ActivityManager am0 = (android.app.ActivityManager)
                                            c0.getSystemService(android.content.Context.ACTIVITY_SERVICE);
                                    java.util.List<android.app.ActivityManager.RunningTaskInfo> ts0 =
                                            am0.getRunningTasks(1);
                                    if (ts0 != null && !ts0.isEmpty()
                                            && ts0.get(0).topActivity != null) {
                                        String pkg = ts0.get(0).topActivity.getPackageName();
                                        log("top pkg=" + pkg);
                                        if ("com.bbk.launcher2".equals(pkg)
                                                || "com.vivo.hiboard".equals(pkg)
                                                || "com.vivo.recents".equals(pkg)
                                                || "com.android.launcher3".equals(pkg)) {
                                            removeMainDeleteButton();
                                            return;
                                        }
                                    }
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                        if (visible) {
                            try {
                                android.content.Context c = appContext();
                                Object st = sMainState;
                                String mainPkg = null;
                                if (st != null) {
                                    Object ti = null;
                                    String[] tf = {"mTaskInfo", "taskInfo", "mTaskinfo"};
                                    for (String f : tf) {
                                        try {
                                            ti = XposedHelpers.getObjectField(st, f);
                                            if (ti != null) {
                                                break;
                                            }
                                        } catch (Throwable ignored) {
                                        }
                                    }
                                    if (ti != null) {
                                        Object act = XposedHelpers.getObjectField(ti, "topActivity");
                                        if (act == null) {
                                            act = XposedHelpers.getObjectField(ti, "baseActivity");
                                        }
                                        if (act != null) {
                                            mainPkg = (String) XposedHelpers.callMethod(act, "getPackageName");
                                        }
                                    }
                                }
                                if (c != null && mainPkg != null) {
                                    android.app.ActivityManager am2 = (android.app.ActivityManager)
                                            c.getSystemService(android.content.Context.ACTIVITY_SERVICE);
                                    java.util.List<android.app.ActivityManager.RunningTaskInfo> ts =
                                            am2.getRunningTasks(1);
                                    if (ts != null && !ts.isEmpty() && ts.get(0).topActivity != null) {
                                        String topPkg = ts.get(0).topActivity.getPackageName();
                                        if (topPkg != null && !topPkg.equals(mainPkg)) {
                                            visible = false;
                                        }
                                    }
                                }
                            } catch (Throwable ignored) {
                            }
                        }
                        if (!visible) {
                            removeMainDeleteButton();
                        }
                    }
                } catch (Throwable ignored) {
                }
                h.postDelayed(this, 100);
            }
        }, 1000);
    }

    private static void addDeleteButton(ViewGroup item) {
        try {
            if (item == null || item.findViewWithTag("eta_del") != null) {
                return;
            }
            android.widget.TextView btn = new android.widget.TextView(item.getContext());
            btn.setText("×");
            btn.setTextColor(0xFFFFFFFF);
            btn.setTextSize(16);
            btn.setGravity(17);
            btn.setBackgroundColor(0xCCE05555);
            btn.setTag("eta_del");
            android.view.ViewGroup.LayoutParams lp;
            if (item instanceof android.widget.RelativeLayout) {
                android.widget.RelativeLayout.LayoutParams rlp =
                        new android.widget.RelativeLayout.LayoutParams(56, 56);
                rlp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_RIGHT);
                rlp.addRule(android.widget.RelativeLayout.ALIGN_PARENT_TOP);
                rlp.rightMargin = 8;
                rlp.topMargin = 8;
                lp = rlp;
            } else {
                lp = new android.view.ViewGroup.LayoutParams(56, 56);
            }
            item.addView(btn, lp);
            btn.setOnClickListener(new DeleteClick());
            log("delete button added");
        } catch (Throwable t) {
            log("add delete button failed: " + t);
        }
    }

    static final class DeleteClick implements android.view.View.OnClickListener {
        @Override
        public void onClick(android.view.View v) {
            log("delete button clicked");
        }
    }

    static final class IconClickListener implements android.view.View.OnClickListener {
        @Override
        public void onClick(android.view.View v) {
            log("icon clicked");
        }
    }

    private static int moveIcons(ViewGroup group, int dx) {
        int moved = 0;
        for (int i = 0; i < group.getChildCount(); i++) {
            View v = group.getChildAt(i);
            if (v instanceof ImageView) {
                v.setTranslationX(dx);
                moved++;
            } else if (v instanceof ViewGroup) {
                moved += moveIcons((ViewGroup) v, dx);
            }
        }
        return moved;
    }

    private static void applyPersp(Point p, float cx, float cy, float halfW, float k) {
        float f = 1.0f + k * ((p.x - cx) / halfW);
        p.y = Math.round(cy + (p.y - cy) * f);
    }

    private static void scalePoint(Point p, float cx, float cy, float s, float dx, float dy) {
        p.x = Math.round(cx + (p.x - cx) * s + dx);
        p.y = Math.round(cy + (p.y - cy) * s + dy);
    }

    private static void readConfig(boolean force) {
        long now = System.currentTimeMillis();
        if (!force && now - lastRead < 2000) {
            return;
        }
        lastRead = now;

        // 优先读 Settings.Global（WebUI 保存时写入）
        try {
            Context app = ctx();
            if (app != null) {
                android.content.ContentResolver cr = app.getContentResolver();
                String s = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_SCALE);
                String x = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_OFFSET_X);
                String y = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_OFFSET_Y);
                String sd = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_SCALE);
                String sdx = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_OFFSET_X);
                String sp = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_PERSPECTIVE);
                String idx = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_ICON_OFFSET_X);
                if (s != null || x != null || y != null || sd != null || sdx != null || sp != null) {
                    cfgScale = parse(s, 1.0f);
                    cfgDx = parse(x, 0.0f);
                    cfgDy = parse(y, 0.0f);
                    cfgSide = parse(sd, 1.0f);
                    cfgSideDx = parse(sdx, 0.0f);
                    cfgPersp = parse(sp, 0.0f);
                    cfgIconDx = parse(idx, 0.0f);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }

        if (!providerBroken) {
            try {
                Context app = ctx();
                if (app == null) {
                    return;
                }
                Bundle b = app.getContentResolver().call(Uri.parse(PROVIDER), "get", null, null);
                if (b != null) {
                    cfgScale = b.getFloat(AppConfig.KEY_MAIN_SCALE, 1.0f);
                    cfgDx = b.getFloat(AppConfig.KEY_MAIN_OFFSET_X, 0.0f);
                    cfgDy = b.getFloat(AppConfig.KEY_MAIN_OFFSET_Y, 0.0f);
                    cfgSide = b.getFloat(AppConfig.KEY_SIDE_SCALE, 1.0f);
                    cfgSideDx = b.getFloat(AppConfig.KEY_SIDE_OFFSET_X, 0.0f);
                    cfgPersp = b.getFloat(AppConfig.KEY_PERSPECTIVE, 0.0f);
                    cfgSideRight = b.getBoolean(AppConfig.KEY_SIDE_RIGHT, false);
                    cfgIconDx = b.getFloat(AppConfig.KEY_ICON_OFFSET_X, 0.0f);
                    return;
                }
                providerBroken = true;
            } catch (Throwable t) {
                providerBroken = true;
            }
        }

        try {
            Context app = ctx();
            if (app != null) {
                android.content.ContentResolver cr = app.getContentResolver();
                String s = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_SCALE);
                String x = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_OFFSET_X);
                String y = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_MAIN_OFFSET_Y);
                String sd = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_SCALE);
                String sdx = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_OFFSET_X);
                String sp = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_PERSPECTIVE);
                String sr = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_SIDE_RIGHT);
                String idx = android.provider.Settings.Global.getString(cr, AppConfig.G_PREFIX + AppConfig.KEY_ICON_OFFSET_X);
                if (s != null || x != null || y != null || sd != null || sdx != null) {
                    cfgScale = parse(s, 1.0f);
                    cfgDx = parse(x, 0.0f);
                    cfgDy = parse(y, 0.0f);
                    cfgSide = parse(sd, 1.0f);
                    cfgSideDx = parse(sdx, 0.0f);
                    cfgPersp = parse(sp, 0.0f);
                    cfgSideRight = "1".equals(sr) || "true".equalsIgnoreCase(sr);
                    cfgIconDx = parse(idx, 0.0f);
                    return;
                }
            }
        } catch (Throwable ignored) {
        }

        try {
            XSharedPreferences p = new XSharedPreferences("com.wefine.workbenchtuner", AppConfig.PREFS);
            p.reload();
            cfgScale = p.getFloat(AppConfig.KEY_MAIN_SCALE, 1.0f);
            cfgDx = p.getFloat(AppConfig.KEY_MAIN_OFFSET_X, 0.0f);
            cfgDy = p.getFloat(AppConfig.KEY_MAIN_OFFSET_Y, 0.0f);
            cfgSide = p.getFloat(AppConfig.KEY_SIDE_SCALE, 1.0f);
            cfgSideDx = p.getFloat(AppConfig.KEY_SIDE_OFFSET_X, 0.0f);
            cfgPersp = p.getFloat(AppConfig.KEY_PERSPECTIVE, 0.0f);
            cfgSideRight = p.getBoolean(AppConfig.KEY_SIDE_RIGHT, false);
            cfgIconDx = p.getFloat(AppConfig.KEY_ICON_OFFSET_X, 0.0f);
        } catch (Throwable ignored) {
        }
    }

    private static float parse(String v, float def) {
        if (v == null) {
            return def;
        }
        try {
            return Float.parseFloat(v);
        } catch (Throwable t) {
            return def;
        }
    }

    private static Context appContext() {
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) {
                return (Context) app;
            }
        } catch (Throwable ignored) {
        }
        try {
            Context c = de.robv.android.xposed.AndroidAppHelper.currentApplication();
            if (c != null) {
                return c;
            }
        } catch (Throwable ignored) {
        }
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object thread = at.getMethod("currentActivityThread").invoke(null);
            if (thread != null) {
                Object ctx = at.getMethod("getSystemContext").invoke(thread);
                if (ctx instanceof Context) {
                    return (Context) ctx;
                }
            }
        } catch (Throwable ignored) {
        }
        return null;
    }

}
