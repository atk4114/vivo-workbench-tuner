package com.wefine.workbenchtuner;

import android.content.Context;
import android.content.SharedPreferences;
import android.provider.Settings;

/** 模块参数存储：本地 prefs + Settings.Global（供 SystemUI 进程读取） */
public final class AppConfig {

    public static final String PREFS = "eta_workbench";

    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_MAIN_SCALE = "main_scale";
    public static final String KEY_MAIN_OFFSET_X = "main_offset_x";
    public static final String KEY_MAIN_OFFSET_Y = "main_offset_y";
    public static final String KEY_SIDE_SCALE = "side_scale";
    public static final String KEY_SIDE_OFFSET_X = "side_offset_x";
    public static final String KEY_ICON_OFFSET_X = "icon_offset_x";
    public static final String KEY_SIDE_RIGHT = "side_right";
    public static final String KEY_CARD_RADIUS = "card_radius";
    public static final String KEY_PERSPECTIVE = "perspective_angle";

    public static final String G_PREFIX = "eta_wb_";
    public static final String KEY_PRESETS = "presets";

    private AppConfig() {
    }

    public static String getPresets(Context c) {
        return prefs(c).getString(KEY_PRESETS, "{}");
    }

    public static void setPresets(Context c, String json) {
        prefs(c).edit().putString(KEY_PRESETS, json).apply();
    }

    public static SharedPreferences prefs(Context c) {
        return c.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public static boolean getBool(Context c, String k, boolean def) {
        return prefs(c).getBoolean(k, def);
    }

    public static void setBool(Context c, String k, boolean v) {
        try {
            Settings.Global.putString(c.getContentResolver(), G_PREFIX + k, v ? "1" : "0");
        } catch (Throwable ignored) {
        }
        try {
            prefs(c).edit().putBoolean(k, v).apply();
        } catch (Throwable ignored) {
        }
    }

    public static float getFloat(Context c, String k, float def) {
        return prefs(c).getFloat(k, def);
    }

    public static void setFloat(Context c, String k, float v) {
        try {
            Settings.Global.putString(c.getContentResolver(), G_PREFIX + k, String.valueOf(v));
        } catch (Throwable ignored) {
        }
        try {
            prefs(c).edit().putFloat(k, v).apply();
        } catch (Throwable ignored) {
        }
    }
}
