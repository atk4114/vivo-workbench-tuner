package com.wefine.workbenchtuner;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

/** 供 SystemUI 进程（hook 端）读取参数 */
public class ConfigProvider extends ContentProvider {

    public static final String AUTHORITY = "com.wefine.workbenchtuner.config";
    public static final Uri URI = Uri.parse("content://" + AUTHORITY + "/config");

    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle b = new Bundle();
        Context c = getContext();
        if (c == null) {
            return b;
        }
        if ("get".equals(method)) {
            b.putBoolean(AppConfig.KEY_ENABLED, AppConfig.getBool(c, AppConfig.KEY_ENABLED, true));
            b.putFloat(AppConfig.KEY_MAIN_SCALE, AppConfig.getFloat(c, AppConfig.KEY_MAIN_SCALE, 1.0f));
            b.putFloat(AppConfig.KEY_MAIN_OFFSET_X, AppConfig.getFloat(c, AppConfig.KEY_MAIN_OFFSET_X, 0.0f));
            b.putFloat(AppConfig.KEY_MAIN_OFFSET_Y, AppConfig.getFloat(c, AppConfig.KEY_MAIN_OFFSET_Y, 0.0f));
            b.putFloat(AppConfig.KEY_SIDE_SCALE, AppConfig.getFloat(c, AppConfig.KEY_SIDE_SCALE, 1.0f));
            b.putFloat(AppConfig.KEY_SIDE_OFFSET_X, AppConfig.getFloat(c, AppConfig.KEY_SIDE_OFFSET_X, 0.0f));
            b.putFloat(AppConfig.KEY_ICON_OFFSET_X, AppConfig.getFloat(c, AppConfig.KEY_ICON_OFFSET_X, 0.0f));
            b.putBoolean(AppConfig.KEY_SIDE_RIGHT, AppConfig.getBool(c, AppConfig.KEY_SIDE_RIGHT, false));
            b.putFloat(AppConfig.KEY_CARD_RADIUS, AppConfig.getFloat(c, AppConfig.KEY_CARD_RADIUS, 0.0f));
            b.putFloat(AppConfig.KEY_PERSPECTIVE, AppConfig.getFloat(c, AppConfig.KEY_PERSPECTIVE, 0.0f));
        }
        return b;
    }

    @Override
    public Cursor query(Uri uri, String[] projection, String selection,
                        String[] selectionArgs, String sortOrder) {
        return null;
    }

    @Override
    public String getType(Uri uri) {
        return null;
    }

    @Override
    public Uri insert(Uri uri, ContentValues values) {
        return null;
    }

    @Override
    public int delete(Uri uri, String selection, String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(Uri uri, ContentValues values, String selection, String[] selectionArgs) {
        return 0;
    }
}
