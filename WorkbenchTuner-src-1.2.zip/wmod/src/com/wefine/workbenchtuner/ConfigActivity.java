package com.wefine.workbenchtuner;

import android.app.Activity;
import android.os.Bundle;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;

import org.json.JSONObject;

/** 本地 WebUI：用 WebView 加载 assets/webui/index.html，参数写入 SharedPreferences */
public class ConfigActivity extends Activity {

    private WebView web;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(true);
        s.setDomStorageEnabled(true);
        web.addJavascriptInterface(new Bridge(this), "EtaWB");
        web.loadUrl("file:///android_asset/webui/index.html");
        setContentView(web, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setTitle("自由工作台");
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    public static class Bridge {

        private final Activity act;

        Bridge(Activity a) {
            act = a;
        }

        private float g(String key, float def) {
            try {
                String v = android.provider.Settings.Global.getString(
                        act.getContentResolver(), AppConfig.G_PREFIX + key);
                return v == null ? def : Float.parseFloat(v);
            } catch (Throwable t) {
                return def;
            }
        }

        @JavascriptInterface
        public String load() {
            try {
                JSONObject o = new JSONObject();
                o.put(AppConfig.KEY_ENABLED, AppConfig.getBool(act, AppConfig.KEY_ENABLED, true));
                o.put(AppConfig.KEY_MAIN_SCALE, AppConfig.getFloat(act, AppConfig.KEY_MAIN_SCALE, 1.0f));
                o.put(AppConfig.KEY_MAIN_OFFSET_X, AppConfig.getFloat(act, AppConfig.KEY_MAIN_OFFSET_X, 0.0f));
                o.put(AppConfig.KEY_MAIN_OFFSET_Y, AppConfig.getFloat(act, AppConfig.KEY_MAIN_OFFSET_Y, 0.0f));
                o.put(AppConfig.KEY_SIDE_SCALE, AppConfig.getFloat(act, AppConfig.KEY_SIDE_SCALE, 1.0f));
                o.put(AppConfig.KEY_SIDE_OFFSET_X, AppConfig.getFloat(act, AppConfig.KEY_SIDE_OFFSET_X, 0.0f));
                o.put(AppConfig.KEY_ICON_OFFSET_X, AppConfig.getFloat(act, AppConfig.KEY_ICON_OFFSET_X, 0.0f));
                o.put("dock_y", getGlobalInt("eta_dock_y", 0));
                o.put("dock_bg_alpha", getGlobalInt("eta_dock_bg_alpha", 120));
                o.put("dock_bg_radius", getGlobalInt("eta_dock_bg_radius", 24));
                o.put("dock_always", android.provider.Settings.System.getInt(
                        act.getContentResolver(), "desktop_dock_state", 0) == 1);
                o.put(AppConfig.KEY_SIDE_RIGHT, AppConfig.getBool(act, AppConfig.KEY_SIDE_RIGHT, false));
                o.put(AppConfig.KEY_CARD_RADIUS, AppConfig.getFloat(act, AppConfig.KEY_CARD_RADIUS, 0.0f));
                o.put(AppConfig.KEY_PERSPECTIVE, AppConfig.getFloat(act, AppConfig.KEY_PERSPECTIVE, 0.0f));
                return o.toString();
            } catch (Throwable t) {
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean save(String json) {
            try {
                JSONObject o = new JSONObject(json);
                if (o.has(AppConfig.KEY_ENABLED)) {
                    AppConfig.setBool(act, AppConfig.KEY_ENABLED, o.getBoolean(AppConfig.KEY_ENABLED));
                }
                if (o.has(AppConfig.KEY_SIDE_RIGHT)) {
                    AppConfig.setBool(act, AppConfig.KEY_SIDE_RIGHT, o.getBoolean(AppConfig.KEY_SIDE_RIGHT));
                }
                if (o.has("dock_always")) {
                    try {
                        android.provider.Settings.System.putInt(act.getContentResolver(),
                                "desktop_dock_state", o.getBoolean("dock_always") ? 1 : 0);
                    } catch (Throwable ignored) {
                    }
                }
                putFloat(o, AppConfig.KEY_MAIN_SCALE);
                putFloat(o, AppConfig.KEY_MAIN_OFFSET_X);
                putFloat(o, AppConfig.KEY_MAIN_OFFSET_Y);
                putFloat(o, AppConfig.KEY_SIDE_SCALE);
                putFloat(o, AppConfig.KEY_SIDE_OFFSET_X);
                putFloat(o, AppConfig.KEY_ICON_OFFSET_X);
                putGlobalInt(o, "dock_y");
                putGlobalInt(o, "dock_bg_alpha");
                putGlobalInt(o, "dock_bg_radius");
                putFloat(o, AppConfig.KEY_CARD_RADIUS);
                putFloat(o, AppConfig.KEY_PERSPECTIVE);
                if (o.has("cast_scale")) {
                    try {
                        android.provider.Settings.Global.putString(act.getContentResolver(),
                                "eta_cast_scale", String.valueOf((float) o.getDouble("cast_scale")));
                    } catch (Throwable ignored) {
                    }
                }
                return true;
            } catch (Throwable t) {
                return false;
            }
        }

        private void putFloat(JSONObject o, String key) throws Exception {
            if (o.has(key)) {
                AppConfig.setFloat(act, key, (float) o.getDouble(key));
            }
        }

        private int getGlobalInt(String key, int def) {
            try {
                String v = android.provider.Settings.Global.getString(act.getContentResolver(), key);
                return v == null ? def : Integer.parseInt(v);
            } catch (Throwable t) {
                return def;
            }
        }

        private void putGlobalInt(org.json.JSONObject o, String key) {
            if (o.has(key)) {
                try {
                    android.provider.Settings.Global.putString(act.getContentResolver(), "eta_" + key,
                            String.valueOf((int) o.getDouble(key)));
                } catch (Throwable ignored) {
                }
            }
        }

        @JavascriptInterface
        public String listPresets() {
            return AppConfig.getPresets(act);
        }

        @JavascriptInterface
        public String loadPreset(String name) {
            try {
                JSONObject all = new JSONObject(AppConfig.getPresets(act));
                return all.optString(name, "{}");
            } catch (Throwable t) {
                return "{}";
            }
        }

        @JavascriptInterface
        public boolean savePreset(String name, String json) {
            try {
                JSONObject all = new JSONObject(AppConfig.getPresets(act));
                all.put(name, new JSONObject(json));
                AppConfig.setPresets(act, all.toString());
                return true;
            } catch (Throwable t) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean deletePreset(String name) {
            try {
                JSONObject all = new JSONObject(AppConfig.getPresets(act));
                all.remove(name);
                AppConfig.setPresets(act, all.toString());
                return true;
            } catch (Throwable t) {
                return false;
            }
        }
    }
}
