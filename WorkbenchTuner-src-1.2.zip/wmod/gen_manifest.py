#!/usr/bin/env python3
"""生成二进制 AndroidManifest.xml (AXML)。

没有 arm64 版本 aapt2 的环境下，用它替代 aapt 打包资源。
支持任意元素嵌套、android 命名空间属性（带 resource id）、字符串/整数/布尔值。
"""
import struct
import sys

ANDROID_NS = "http://schemas.android.com/apk/res/android"

# 必须固定顺序并全部写进 resource map（索引即字符串池下标）
ATTRS = [
    ("versionCode", 0x0101021B),
    ("versionName", 0x0101021C),
    ("minSdkVersion", 0x0101020C),
    ("targetSdkVersion", 0x01010270),
    ("name", 0x01010003),
    ("value", 0x01010024),
    ("exported", 0x01010010),
    ("authorities", 0x01010018),
    ("grantUriPermissions", 0x0101001B),
    ("label", 0x01010001),
]
ATTR_ID = dict(ATTRS)

strings = [a for a, _ in ATTRS]
index = {v: i for i, v in enumerate(strings)}


def s(val):
    if val not in index:
        index[val] = len(strings)
        strings.append(val)
    return index[val]


def utf16_pool(items):
    body = b""
    offsets = []
    for it in items:
        offsets.append(len(body))
        body += struct.pack("<H", len(it)) + it.encode("utf-16-le") + b"\x00\x00"
        while len(body) % 4:
            body += b"\x00"
    total = 28 + 4 * len(items) + len(body)
    header = struct.pack("<HHIIIIII", 0x0001, 28, total, len(items), 0, 0,
                         28 + 4 * len(items), 0)
    header += b"".join(struct.pack("<I", o) for o in offsets)
    return header + body


def res_map():
    ids = [rid for _, rid in ATTRS]
    return struct.pack("<HHI", 0x0180, 8, 8 + 4 * len(ids)) + b"".join(
        struct.pack("<I", i) for i in ids)


def ns_chunk(end, prefix, uri):
    return struct.pack("<HHIIIII", 0x0101 if end else 0x0100, 16, 24,
                       0xFFFFFFFF, 0xFFFFFFFF, s(prefix), s(uri))


def typed(value):
    if isinstance(value, bool):
        return 0x12, 0xFFFFFFFF if value else 0, 0xFFFFFFFF
    if isinstance(value, int):
        return 0x10, value, 0xFFFFFFFF
    raw = s(value)
    return 0x03, raw, raw


def start_element(name, attrs):
    body = b""
    for ns, an, val in attrs:
        dtype, data, raw = typed(val)
        body += struct.pack("<III", s(ns) if ns else 0xFFFFFFFF, s(an), raw)
        body += struct.pack("<HBBI", 8, 0, dtype, data)
    size = 16 + 20 + 20 * len(attrs)
    out = struct.pack("<HHIII", 0x0102, 16, size, 0xFFFFFFFF, 0xFFFFFFFF)
    out += struct.pack("<II", 0xFFFFFFFF, s(name))
    out += struct.pack("<HHHHHH", 20, 20, len(attrs), 0, 0, 0)
    return out + body


def end_element(name):
    return struct.pack("<HHIIIII", 0x0103, 16, 24, 0xFFFFFFFF, 0xFFFFFFFF,
                       0xFFFFFFFF, s(name))


def E(name, attrs=None, children=None):
    return {"name": name, "attrs": attrs or [], "children": children or []}


def build(root):
    chunks = [ns_chunk(False, "android", ANDROID_NS)]
    stack = [(root, False)]
    # 深度优先生成
    def walk(node):
        chunks.append(start_element(node["name"], node["attrs"]))
        for ch in node["children"]:
            walk(ch)
        chunks.append(end_element(node["name"]))
    walk(root)
    chunks.append(ns_chunk(True, "android", ANDROID_NS))

    pool = utf16_pool(strings)  # 必须在所有 s() 之后
    payload = pool + res_map() + b"".join(chunks)
    return struct.pack("<HHI", 0x0003, 8, 8 + len(payload)) + payload


def make_manifest(package, version_code, version_name, min_sdk, target_sdk,
                  label, metas, activity, provider):
    children = [
        E("uses-sdk", [
            (ANDROID_NS, "minSdkVersion", min_sdk),
            (ANDROID_NS, "targetSdkVersion", target_sdk),
        ]),
        E("uses-permission", [
            (ANDROID_NS, "name", "android.permission.WRITE_SECURE_SETTINGS"),
        ]),
        E("application", [(ANDROID_NS, "label", label)], [
            E("activity", [
                (ANDROID_NS, "name", activity),
                (ANDROID_NS, "exported", True),
                (ANDROID_NS, "label", label),
            ], [
                E("intent-filter", [], [
                    E("action", [(ANDROID_NS, "name", "android.intent.action.MAIN")]),
                    E("category", [(ANDROID_NS, "name", "android.intent.category.LAUNCHER")]),
                ]),
            ]),
            E("provider", [
                (ANDROID_NS, "name", provider),
                (ANDROID_NS, "authorities", package + ".config"),
                (ANDROID_NS, "exported", True),
                (ANDROID_NS, "grantUriPermissions", True),
            ]),
        ] + [
            E("meta-data", [
                (ANDROID_NS, "name", k),
                (ANDROID_NS, "value", v),
            ]) for k, v in metas
        ]),
    ]
    return E("manifest", [
        (None, "package", package),
        (ANDROID_NS, "versionCode", version_code),
        (ANDROID_NS, "versionName", version_name),
    ], children)


if __name__ == "__main__":
    out = sys.argv[1] if len(sys.argv) > 1 else "AndroidManifest.xml"
    metas = [
        ("xposedmodule", "true"),
        ("xposedminversion", 93),
        ("xposedscope", "com.android.systemui,com.bbk.launcher2,com.android.settings"),
        ("xposedsharedprefs", "true"),
    ]
    root = make_manifest("com.wefine.workbenchtuner", 102, "1.2", 29, 35,
                         "自由工作台布局",
                         metas,
                         ".ConfigActivity",
                         ".ConfigProvider")
    data = build(root)
    with open(out, "wb") as f:
        f.write(data)
    print("written %s (%d bytes)" % (out, len(data)))
