#!/bin/sh
# 构建 + 打包 + 签名 LSPosed 模块（含本地 WebUI）
set -e
SDK=/workspace/android/sdk
AJ=$SDK/platform35/android-35/android.jar
D8JAR=$SDK/bt34/android-14/lib/d8.jar
BT=$SDK/bt34/android-14
MOD=/workspace/android/wmod
VERSION=1.2

echo "== 1. 编译 Xposed API stub =="
rm -rf "$MOD/stubout"
mkdir -p "$MOD/stubout"
javac --release 8 -nowarn -cp "$AJ" -d "$MOD/stubout" $(find "$MOD/stub" -name '*.java')
jar cf "$MOD/xposed-api-stub.jar" -C "$MOD/stubout" .

echo "== 2. 编译模块 =="
rm -rf "$MOD/out"
mkdir -p "$MOD/out"
javac --release 8 -nowarn -cp "$AJ:$MOD/xposed-api-stub.jar" -d "$MOD/out" $(find "$MOD/src" -name '*.java')
echo "   classes: $(find "$MOD/out" -name '*.class' | wc -l)"

echo "== 3. d8 转 dex =="
rm -f "$MOD/classes.dex"
java -cp "$D8JAR" com.android.tools.r8.D8 --release --min-api 29 --lib "$AJ" \
  --output "$MOD" $(find "$MOD/out" -name '*.class')
ls -l "$MOD/classes.dex"

echo "== 4. 打包 =="
OUT=$MOD/dist
rm -rf "$OUT"
mkdir -p "$OUT/apk/assets/webui" "$OUT/apk/META-INF/xposed"

python3 "$MOD/gen_manifest.py" "$OUT/apk/AndroidManifest.xml"
cp "$MOD/classes.dex" "$OUT/apk/classes.dex"
cp "$MOD/assets/webui/index.html" "$OUT/apk/assets/webui/index.html"
printf 'com.wefine.workbenchtuner.HookEntry\n' > "$OUT/apk/assets/xposed_init"

cat > "$OUT/apk/META-INF/xposed/module.prop" <<EOF
moduleVersion=$VERSION
moduleVersionCode=2
moduleName=自由工作台布局
minApiVersion=93
targetApiVersion=93
EOF
printf 'com.wefine.workbenchtuner.HookEntry\n' > "$OUT/apk/META-INF/xposed/java_init.list"
printf 'com.android.systemui\ncom.bbk.launcher2\ncom.android.settings\ncom.vivo.upnpserver\n' > "$OUT/apk/META-INF/xposed/scope.list"

cd "$OUT/apk"
zip -q -r "$OUT/unsigned.apk" AndroidManifest.xml classes.dex assets META-INF

echo "== 5. 签名 =="
KEYSTORE=$MOD/debug.keystore
if [ ! -f "$KEYSTORE" ]; then
  keytool -genkeypair -keystore "$KEYSTORE" -alias androiddebugkey -storepass android \
    -keypass android -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Android Debug,O=Android,C=US" >/dev/null 2>&1
fi

"$BT/apksigner" sign --ks "$KEYSTORE" --ks-pass pass:android --key-pass pass:android \
  --min-sdk-version 29 --out "$OUT/EtaWorkbench-$VERSION.apk" "$OUT/unsigned.apk"
"$BT/apksigner" verify "$OUT/EtaWorkbench-$VERSION.apk" && echo "   signature ok"
ls -l "$OUT/EtaWorkbench-$VERSION.apk"
echo "== done =="
